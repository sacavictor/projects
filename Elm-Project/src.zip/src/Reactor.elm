module Reactor exposing (..)

{-| Convenience file that can be used to test the app with the local server
-}

import Main


main =
    Main.reactorMain
